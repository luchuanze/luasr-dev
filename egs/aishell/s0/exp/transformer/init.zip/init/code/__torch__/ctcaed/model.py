class CtcAedModel(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  sos : int
  eos : int
  vocab_size : int
  ignore_id : int
  ctc_weight : float
  encoder : __torch__.ctcaed.encoder.BaseEncoder
  def forward(self: __torch__.ctcaed.model.CtcAedModel,
    speech: Tensor,
    speech_lengths: Tensor,
    token: Tensor,
    token_lengths: Tensor) -> NoneType:
    _0 = torch.eq(torch.dim(token_lengths), 1)
    if _0:
      pass
    else:
      ops.prim.RaiseException("AssertionError: ")
    _1 = torch.eq((torch.size(speech))[0], (torch.size(speech_lengths))[0])
    if _1:
      _3 = torch.eq((torch.size(speech_lengths))[0], (torch.size(token))[0])
      _2 = _3
    else:
      _2 = False
    if _2:
      _5 = torch.eq((torch.size(token))[0], (torch.size(token_lengths))[0])
      _4 = _5
    else:
      _4 = False
    if _4:
      pass
    else:
      ops.prim.RaiseException("AssertionError: ")
    encoder_out = (self.encoder).forward(speech, speech_lengths, )
    return encoder_out
