class BaseEncoder(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  output_size : int
  global_cmvn : NoneType
  subsampling_conv : __torch__.ctcaed.encoder.SubsamplingConv
  embed : __torch__.ctcaed.encoder.PositionalEncoding
  def forward(self: __torch__.ctcaed.encoder.BaseEncoder,
    x: Tensor,
    x_lens: Tensor) -> NoneType:
    _0 = __torch__.ctcaed.encoder.make_pad_mask
    T = torch.size(x, 1)
    mask = torch.bitwise_not(torch.unsqueeze(_0(x_lens, T, ), 1))
    _1 = (self.subsampling_conv).forward(x, mask, 0, )
    x0, mask0, = _1
    _2 = (self.embed).forward(x0, 0, )
    return None
class SubsamplingConv(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  subsampling_rate : int
  conv : __torch__.torch.nn.modules.container.Sequential
  out : __torch__.torch.nn.modules.container.___torch_mangle_1.Sequential
  def forward(self: __torch__.ctcaed.encoder.SubsamplingConv,
    x: Tensor,
    x_mask: Tensor,
    offset: int=0) -> Tuple[Tensor, Tensor]:
    x1 = torch.unsqueeze(x, 1)
    x2 = (self.conv).forward(x1, )
    b, c, t, f, = torch.size(x2)
    _3 = self.out
    _4 = torch.contiguous(torch.transpose(x2, 1, 2))
    _5 = torch.view(_4, [b, t, torch.mul(c, f)])
    x3 = (_3).forward(_5, )
    _6 = torch.slice(torch.slice(torch.slice(x_mask), 1), 2, None, -2, 2)
    _7 = torch.slice(torch.slice(torch.slice(_6), 1), 2, None, -2, 2)
    return (x3, _7)
class PositionalEncoding(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  d_model : int
  xscale : float
  max_len : int
  pe : Tensor
  dropout : __torch__.torch.nn.modules.dropout.Dropout
  def forward(self: __torch__.ctcaed.encoder.PositionalEncoding,
    x: Tensor,
    offset: int=0) -> Tuple[Tensor, Tensor]:
    _8 = torch.lt(torch.add(offset, torch.size(x, 1)), self.max_len)
    if _8:
      pass
    else:
      ops.prim.RaiseException("AssertionError: ")
    _9 = torch.to(self.pe, ops.prim.device(x))
    self.pe = _9
    pos_emb = torch.slice(torch.slice(self.pe), 1, offset, torch.add(offset, torch.size(x, 1)))
    x4 = torch.add(torch.mul(x, self.xscale), pos_emb)
    _10 = ((self.dropout).forward(x4, ), (self.dropout).forward(pos_emb, ))
    return _10
def make_pad_mask(lengths: Tensor,
    max_len: int=0) -> Tensor:
  batch_size = torch.size(lengths, 0)
  if torch.gt(max_len, 0):
    max_len0 = max_len
  else:
    max_len0 = torch.item(torch.max(lengths))
  seq_range = torch.arange(0, max_len0, dtype=4, layout=None, device=ops.prim.device(lengths))
  seq_range_expand = torch.expand(torch.unsqueeze(seq_range, 0), [batch_size, int(max_len0)])
  seq_length_expand = torch.unsqueeze(lengths, -1)
  mask = torch.ge(seq_range_expand, seq_length_expand)
  return mask
